# RecycleShare - Geri Dönüşüm Paylaşım Platformu

## Grup 47 - Veritabanı Lab 2526 Projesi

### 🚀 Hızlı Kurulum ve Çalıştırma

Proje **hazır yapılandırılmış** olarak gelmektedir. `.env` dosyaları dahildir.

#### 1. Gereksinimler
- Node.js 18+
- PostgreSQL (Lokal veya Cloud)

#### 2. Backend Çalıştırma

```bash
cd backend
npm install

# Seçenek A: Lokal Veritabanı (Otomatik oluşturulur)
npm run dev:local

# Seçenek B: Hazır Neon Cloud Veritabanı (.env içindeki ayarlarla)
npm run dev
```

#### 3. Frontend Çalıştırma

```bash
cd frontend
npm install
npm run dev
```

Frontend: http://localhost:5173
Backend: http://localhost:5001

### 🌐 Canlı Demo
- **Frontend:** https://recycle-share.vercel.app
- **Backend:** https://recycleshare.onrender.com

### 📊 Veritabanı Bilgileri
- Platform: Neon Cloud / Local PostgreSQL
- Schema: database/schema.sql
- Tabloları `npm run dev:local` komutu otomatik oluşturur.

### 📋 Ödev Notları
- Tüm gereksinimler (Trigger, Constraint, View, vb.) `schema.sql` içindedir.
- Detaylı proje raporu `rapor.pdf` dosyasındadır.
